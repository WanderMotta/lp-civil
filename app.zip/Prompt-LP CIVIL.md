Aqui está o **prompt completo em português** para criação de **Landing Page + Anúncios Google Ads** voltados para **Advogado de Direito Civil**, usando o modelo base de “Direito Trabalhista” e ajustando conforme os serviços fornecidos 👇

---

## 🧩 **Prompt para Landing Page – Direito Civil (com base no modelo fornecido)**

---

### **1. Estrutura da Landing Page**

#### **Cabeçalho (Header)**

* Logotipo do escritório (lado esquerdo);
* Botão fixo: **“Fale Agora!!!”** (WhatsApp);
* Telefone clicável e link direto para WhatsApp.

**Chamada curta:**

> “Resolvemos com agilidade e segurança. Atendimento rápido, 100% ONLINE e sigiloso.”

---

### **Seção de Destaque (Hero Section)**

**Título forte:**

> “Precisa de um advogado especializado em Direito Civil?”

**Subtítulo:**

> “Atendimento humanizado e soluções jurídicas rápidas para divórcio, guarda, pensão, inventário e mais.”

**CTA:**

> “📞 Fale Agora!!!” (botão fixo com link para WhatsApp)

**Imagem sugerida:** advogado atendendo casal ou família / balança da justiça / escritório moderno.

---

### **Principais Serviços Oferecidos**

**Título:** “Como podemos te ajudar?”

| Serviço                                                     | Descrição                                                                                                                             |
| ----------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------- |
| **Divórcio**                                                | Encerramos o casamento de forma rápida e segura, consensual ou litigiosa, protegendo seus direitos e evitando desgaste desnecessário. |
| **Separação de corpos**                                     | Medida imediata para afastar os cônjuges e garantir proteção jurídica até a conclusão do divórcio.                                    |
| **União estável**                                           | Reconhecemos ou dissolvemos a união estável, regulando direitos, bens e responsabilidades com segurança.                              |
| **Pensão alimentícia**                                      | Definimos, revisamos ou encerramos a pensão, buscando equilíbrio entre quem paga e quem recebe.                                       |
| **Guarda de filhos**                                        | Ajustamos guarda unilateral ou compartilhada e visitas, sempre priorizando o bem-estar da criança.                                    |
| **Inventário**                                              | Organizamos a herança por via judicial ou extrajudicial, com partilha justa e solução ágil.                                           |
| **Investigação de paternidade**                             | Confirmamos ou contestamos vínculos biológicos, garantindo direitos de pais e filhos.                                                 |
| **Reconhecimento e dissolução de paternidade socioafetiva** | Regulamos juridicamente vínculos de afeto, com foco na realidade familiar e no melhor interesse do filho.                             |
| **Acordos de convivência ou pré-nupciais**                  | Criamos contratos claros para organizar responsabilidades e resguardar bens do casal.                                                 |
| **Doações em vida**                                         | Estruturamos doações com segurança jurídica, evitando problemas futuros entre herdeiros.                                              |

**Sugestão visual:** ícones representando cada serviço (⚖️ ❤️ 👨‍👩‍👧‍👦 💍 🧾).

---

### **Prova Social e Credibilidade**

**Título:** “Por que nos escolher?”

* +10 anos de experiência em Direito Civil e de Família;
* Atendimento 100% sigiloso e humanizado;
* Casos resolvidos com êxito;
* Avaliações positivas de clientes satisfeitos.

**(Incluir espaço para depoimentos simulados).**

---

### **Como Funciona o Atendimento**

1. Envie sua mensagem pelo WhatsApp ou formulário;
2. Avaliação gratuita e rápida do seu caso;
3. Receba orientação jurídica imediata.

**CTA:** “🔍 Avaliar meu caso agora” (botão de destaque).

---

### **Formulário / Contato**

**Campos sugeridos:**

* Nome completo;
* WhatsApp
* e-mail;
* Tipo de caso (menu: divórcio, guarda, pensão, inventário, etc.);
* Mensagem.

**Mensagem lateral:**

> “Garantimos sigilo total e resposta rapida.”

---

### **Rodapé (Footer)**

* Aviso OAB:

  > “Este site tem caráter meramente informativo, conforme o Código de Ética da OAB.”

---

### **2. Sugestão de Estrutura para Anúncios Google Ads (Direito Civil)**

#### **Título 1:**

> “Advogado Especialista em Direito Civil”

#### **Título 2:**

> “Atendimento Rápido e 100% Online”

#### **Título 3:**

> “Divórcio, Guarda, Pensão, Inventário e Mais”

#### **Descrição 1:**

> “Soluções jurídicas seguras e discretas. Atendimento online, prático e sigiloso. Fale com um advogado agora!”

#### **Descrição 2:**

> “Mais de 10 anos de experiência em Direito Civil e de Família. Agende sua consulta gratuita.”

#### **Extensões sugeridas:**

* Sitelinks: “Divórcio | Pensão | Guarda | Inventário”
* Chamada: “Fale direto com um advogado – Clique aqui”
* Local: Endereço do escritório
* Frase de destaque: “Atendimento humanizado e rápido”

---

