@echo off
echo === INICIANDO UPLOAD PARA GITHUB ===

REM Inicializar repositório Git
echo Inicializando repositorio Git...
git init

REM Adicionar todos os arquivos
echo Adicionando todos os arquivos...
git add .

REM Fazer commit inicial
echo Realizando commit inicial...
git commit -m "Commit inicial - upload de todos os arquivos da pasta"

REM Adicionar repositório remoto
echo Conectando ao repositorio remoto...
git remote add origin https://gitea.aplicativopro.com/wander/LP-Trablhista.git

REM Definir branch principal
echo Definindo branch principal como 'main'...
git branch -M main

REM Fazer push para o GitHub
echo Fazendo upload para o GitHub...
git push -u origin main

echo === UPLOAD CONCLUIDO COM SUCESSO! ===

pause